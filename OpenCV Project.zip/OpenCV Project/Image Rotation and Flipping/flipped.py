import cv2

image = cv2.imread("python_image.jpg")

if image is None:
    print("Could not load the image")
else:
    flipped_horizontal = cv2.flip(image, 1) # 1 means horizontal
    flipped_vertical = cv2.flip(image, 0) # 0 means vertical
    flipped_both = cv2.flip(image, -1)  # -1 means both horizontal & vertical


    cv2.imshow("Original Image", image)
    cv2.imshow("Flipped Horizontal", flipped_horizontal)
    cv2.imshow("Flipped Vertical", flipped_vertical)
    cv2.imshow("Flipped Both", flipped_both)

    cv2.imwrite("flipped_horizontal.jpg", flipped_horizontal)
    cv2.imwrite("flipped_vertical.jpg", flipped_vertical)
    cv2.imwrite("flipped_both.jpg", flipped_both)

    cv2.waitKey(0)
    cv2.destroyAllWindows()
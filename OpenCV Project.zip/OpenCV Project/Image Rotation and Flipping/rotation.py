import cv2

image = cv2.imread("python_image.jpg")

if image is None:
    print("Could not load the image")
else:
    (h,w) = image.shape[:2]

    center = (w//2, h//2)
    M = cv2.getRotationMatrix2D(center, 45, 1.0) # 90 - degree, 1.0 - scale, (1.0 means same size, 0.5 means half of the image,2.0 means double it)
    rotated = cv2.warpAffine(image, M, (w, h))

    cv2.imshow("Original Image", image)
    cv2.imshow("Rotational Image", rotated)

    cv2.imwrite("rotation_output.jpg", rotated)

    cv2.waitKey(0)
    cv2.destroyAllWindows()
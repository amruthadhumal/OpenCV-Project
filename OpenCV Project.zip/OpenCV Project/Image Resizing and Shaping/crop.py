import cv2

image = cv2.imread("python_image.jpg")

if image is not None:
    cropped = image[100:200, 50:150] # image(startY:endY , startX:endX), crop image by using slice

    cv2.imshow("Original image", image)
    cv2.imshow("Cropped image", cropped)
    
    cv2.imwrite("cropped_output.jpg", cropped)

    cv2.waitKey(0)
    cv2.destroyAllWindows()
import cv2

image = cv2.imread("python_image.jpg")

if image is not None:
    success = cv2.imwrite("output_image.jpg",image)
    if success:
        print("Image saved successfully as 'output_image'")
    else:
        print("Failed to save an image")
else:
    print("Error: Could not load image")
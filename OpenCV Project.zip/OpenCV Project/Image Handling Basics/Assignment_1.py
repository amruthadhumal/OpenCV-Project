import cv2

image_location = input("Enter image location: ")
if image_location is not None:
    image_load = cv2.imread(image_location) 
    gray = cv2.cvtColor(image_load,cv2.COLOR_BGR2GRAY)

user_input = input("Please select the options \n1.Show\n2.Save\n")
if user_input == '1':
    cv2.imshow("Grayscale Image", gray)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
elif user_input == '2':
    cv2.imwrite("new_image.jpg", gray)
else:
    print("Incorrect input")
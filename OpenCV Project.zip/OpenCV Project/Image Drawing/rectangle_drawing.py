import cv2

image = cv2.imread("python_image.jpg")

if image is None:
    print("Oops! Your image is not working")
else:
    print("Image loaded successfully!")

    point1 = (50,50) # source - (x,y),top-left corner
    point2 = (150,100) # destination - (x,y) - bottom-right corner
    color = (0, 0, 255)
    thickness = 3 # -1 means fill the rectangle with color

    cv2.rectangle(image, point1, point2, color, thickness)

    cv2.imshow("Rectangle Drawing", image)
    cv2.imwrite("rectangle_draw.jpg", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

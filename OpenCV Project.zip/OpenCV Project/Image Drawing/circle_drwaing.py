import cv2

image = cv2.imread("python_image.jpg")

if image is None:
    print("Oops! Your image is not working")
else:
    print("Image loaded successfully!")

    center = (160,80) # in (x,y) format
    radius = 20 # should be in pixel
    color = (0, 0, 255)
    thickness = 3 # -1 means fill the rectangle with color

    cv2.circle(image, center, radius, color, thickness)

    cv2.imshow("Circle Drawing", image)
    cv2.imwrite("circle_draw.jpg", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

import cv2

image = cv2.imread("python_image.jpg")

if image is None:
    print("Oops! Your image is not working")
else:
    print("Image loaded successfully!")

    cv2.putText(image, "Hello Python Programmers", (20,30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)

    cv2.imshow("Adding Text", image)
    cv2.imwrite("add_text.jpg", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

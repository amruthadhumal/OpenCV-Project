import cv2

image = cv2.imread("python_image.jpg")

if image is None:
    print("Oops! Your image is not working")
else:
    print("Image loaded successfully!")

    point1 = (150,100) # source - (x,y)
    point2 = (260,100) # destination - (x,y)
    color = (255, 0, 0)
    thickness = 4

    cv2.line(image, point1, point2, color, thickness)

    cv2.imshow("Line Drawing", image)
    cv2.imwrite("line_draw.jpg", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
